from flask import Flask, render_template, jsonify, request, redirect, url_for
import os
import pandas as pd

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/data')
def get_data():
    try:
        # Check if data file exists
        excel_file = os.getenv("EXCEL_FILE_PATH", "processed_data.xlsx")
        if not os.path.exists(excel_file):
            excel_file = "sample_data.xlsx"
            if not os.path.exists(excel_file):
                return jsonify({"error": "No data file found"}), 404
        
        # Read data from Excel file
        df = pd.read_excel(excel_file)
        data = df.to_dict(orient='records')
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)