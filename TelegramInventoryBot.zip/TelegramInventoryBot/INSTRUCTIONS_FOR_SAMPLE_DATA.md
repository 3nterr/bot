# Instructions for Creating sample_data.xlsx

Since binary Excel files cannot be generated directly through this interface, please follow these instructions to create the necessary sample data file:

## Structure of sample_data.xlsx

Create an Excel file with the following columns:
- Phone Number
- Shelf
- Row
- Column

## Sample Data

Add the following sample records to the file:

| Phone Number | Shelf | Row | Column |
|--------------|-------|-----|--------|
| 1234567890   | A     | 1   | 10     |
| 0987654321   | B     | 2   | 20     |
| 5555555555   | C     | 3   | 30     |
| 2223334444   | D     | 4   | 40     |
| 9998887777   | E     | 5   | 50     |

## Saving the File

1. Save this Excel file as `sample_data.xlsx` in the same directory as the bot.py file
2. Ensure the file is in .xlsx format (Excel 2007 or newer)

## Note

If you don't create this file manually, the bot has a fallback mechanism to create a basic sample data file with fewer entries.
