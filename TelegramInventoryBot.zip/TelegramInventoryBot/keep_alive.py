from flask import Flask
from threading import Thread
import logging

# تعطيل سجلات Flask للحد من الضوضاء
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

app = Flask('')

@app.route('/')
def home():
    return "بوت البحث عن مواقع الهواتف قيد التشغيل!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    """تشغيل خادم Flask في خلفية للحفاظ على استمرارية البوت"""
    t = Thread(target=run)
    t.daemon = True  # تعيين الخيط ليكون daemon
    t.start()