from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
import pandas as pd
import os
import logging
from keep_alive import keep_alive

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# تحميل البيانات من ملف Excel
def load_data_from_excel(file_path):
    try:
        df = pd.read_excel(file_path)
        # تحويل البيانات إلى قاموس لتسهيل البحث
        data_dict = {str(row['Phone Number']).strip(): (row['Shelf'], row['Row'], row['Column']) 
                    for index, row in df.iterrows()}
        logger.info(f"Loaded {len(data_dict)} records from {file_path}")
        return data_dict
    except Exception as e:
        logger.error(f"Error loading data from Excel file: {e}")
        return {}

# دالة لإنشاء ملف بيانات للتجربة
def create_sample_data(filename):
    try:
        # Create a simple dataframe with sample data
        data = {
            'Phone Number': ['1234567890', '0987654321', '5555555555'],
            'Shelf': ['A', 'B', 'C'],
            'Row': [1, 2, 3],
            'Column': [10, 20, 30]
        }
        df = pd.DataFrame(data)
        df.to_excel(filename, index=False)
        logger.info(f"Created sample data file: {filename}")
    except Exception as e:
        logger.error(f"Error creating sample data: {e}")

# دالة لمعالجة أمر البدء
def start(update: Update, context: CallbackContext):
    user = update.effective_user
    update.message.reply_text(
        f"مرحبًا {user.first_name}! 👋\n\n"
        "أرسل لي رقم الخدمة، وسأرد عليك بالبورت الخاص به (Shelf / Row / Column)."
    )

# دالة لعرض المساعدة
def help_command(update: Update, context: CallbackContext):
    update.message.reply_text(
        "📌 تعليمات استخدام البوت:\n\n"
        "- أرسل رقم الهاتف مباشرة للبحث عنه\n"
        "- تأكد من إدخال الرقم بشكل صحيح\n\n"
        "/start - بدء استخدام البوت\n"
        "/help - عرض هذه التعليمات"
    )

# دالة لإعادة تحميل البيانات
def reload_data(update: Update, context: CallbackContext):
    global data_dict, file_path
    data_dict = load_data_from_excel(file_path)
    update.message.reply_text(f"تم إعادة تحميل البيانات. {len(data_dict)} سجل تم تحميله.")

# دالة للبحث عن معلومات رقم الهاتف
def get_info(update: Update, context: CallbackContext):
    phone_number = update.message.text.strip()
    
    logger.info(f"Received query for phone number: {phone_number}")
    
    # البحث عن رقم الخدمة في البيانات
    if phone_number in data_dict:
        shelf, row, column = data_dict[phone_number]
        update.message.reply_text(
            f"🔍 معلومات الموقع:\n\n"
            f"📱 رقم الهاتف: {phone_number}\n"
            f"📚 الرف (Shelf): {shelf}\n"
            f"📋 الصف (Row): {row}\n"
            f"📍 العمود (Column): {column}"
        )
    else:
        # محاولة تطبيع رقم الهاتف
        clean_number = ''.join(filter(str.isdigit, phone_number))
        
        # البحث عن أرقام مشابهة
        potential_matches = [
            num for num in data_dict.keys() 
            if clean_number in num or num in clean_number
        ]
        
        if potential_matches:
            # عرض الأرقام المشابهة
            message = "لم أجد هذا الرقم بالضبط، لكن وجدت أرقام مشابهة:\n\n"
            for i, match in enumerate(potential_matches[:5], 1):  # عرض 5 نتائج كحد أقصى
                shelf, row, column = data_dict[match]
                message += f"{i}. رقم الهاتف: {match}\n"
                message += f"   الرف: {shelf}, الصف: {row}, العمود: {column}\n\n"
            update.message.reply_text(message)
        else:
            # لم يتم العثور على أي نتائج
            update.message.reply_text(
                "⚠️ رقم الهاتف غير موجود في البيانات.\n\n"
                "يرجى التأكد من كتابة الرقم بشكل صحيح والمحاولة مرة أخرى."
            )

# دالة لمعالجة الأخطاء
def error_handler(update: Update, context: CallbackContext):
    logger.error(f"Error: {context.error} - Update: {update}")
    try:
        update.message.reply_text(
            "⚠️ حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقًا."
        )
    except:
        pass

def main():
    global data_dict, file_path
    
    # تشغيل خادم Flask في الخلفية للحفاظ على استمرارية البوت
    keep_alive()
    
    # تحديد مسار ملف البيانات
    file_path = os.getenv("EXCEL_FILE_PATH", "processed_data.xlsx")
    
    # التحقق من وجود ملف البيانات
    if not os.path.exists(file_path):
        logger.warning(f"Excel file {file_path} not found, creating sample data file")
        # إنشاء ملف بيانات للتجربة
        create_sample_data("sample_data.xlsx")
        file_path = "sample_data.xlsx"
    
    # تحميل البيانات
    data_dict = load_data_from_excel(file_path)
    
    # أدخل التوكن الخاص بالبوت هنا
    token = os.getenv("TELEGRAM_BOT_TOKEN", "7768505658:AAFoSSmeom66QAasgjru33sZLZOEa1fC1Vo")

    # إعدادات البوت
    updater = Updater(token, use_context=True)
    dispatcher = updater.dispatcher

    # إضافة معالجات الأوامر
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("help", help_command))
    dispatcher.add_handler(CommandHandler("reload", reload_data))
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, get_info))
    
    # إضافة معالج الأخطاء
    dispatcher.add_error_handler(error_handler)

    # بدء البوت
    updater.start_polling()
    logger.info("Bot started!")
    updater.idle()

if __name__ == '__main__':
    main()
