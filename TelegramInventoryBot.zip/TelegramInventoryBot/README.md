# Telegram Phone Location Bot

A Telegram bot that looks up port/location information (Shelf/Row/Column) based on phone numbers stored in an Excel file.

## Features

- Quickly search for phone numbers in an Excel database
- Returns formatted location data (Shelf/Row/Column) for each phone number
- Arabic text interface
- Simple command structure
- Fuzzy matching for similar phone numbers

## Setup

1. **Install requirements**

   ```bash
   pip install -r requirements.txt
   ```

2. **Prepare your data file**

   The bot expects an Excel file (by default `processed_data.xlsx`) with the following columns:
   - Phone Number
   - Shelf
   - Row
   - Column
   
   If no file is found, a sample data file will be created automatically.

3. **Set your Telegram Bot Token**

   You can set your bot token as an environment variable:
   ```bash
   export TELEGRAM_BOT_TOKEN="your_token_here"
   ```
   
   Or, edit the default token in the `bot.py` file.

4. **Run the bot**

   ```bash
   python bot.py
   ```

## Commands

- `/start` - Start the bot and get a welcome message
- `/help` - Display usage instructions
- `/reload` - Reload the Excel data file (useful after updates to the file)

## How to Use

1. Start a chat with your bot on Telegram
2. Send any phone number
3. The bot will respond with the location information (Shelf/Row/Column)
4. If the exact number isn't found, the bot will suggest similar matches

## Manual Excel File Creation

If you need to create your own data file:

1. Open Microsoft Excel or any compatible spreadsheet software
2. Create a new spreadsheet with the following columns:
   - Phone Number
   - Shelf
   - Row
   - Column
3. Enter your data in these columns
4. Save the file as `processed_data.xlsx` in the same directory as the bot
